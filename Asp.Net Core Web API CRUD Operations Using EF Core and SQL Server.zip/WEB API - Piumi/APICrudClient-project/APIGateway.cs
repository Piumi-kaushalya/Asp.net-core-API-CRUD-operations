﻿using APICrudClient.Models;
using Newtonsoft.Json;
using System.Data;
using System.Net;
using System.Text;

namespace APICrudClient
{
    public class APIGateway
    {
        private String url = "https://localhost:7267/api/Employee";

        private HttpClient httpClient = new HttpClient();

        public List<Employee> ListEmployees()
        {
            List<Employee> employees = new List<Employee>();
            if (url.Trim().Substring(0, 5).ToLower() == "https")
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            try
            {
                HttpResponseMessage response = httpClient.GetAsync(url).Result;
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    var datacol = JsonConvert.DeserializeObject<List<Employee>>(result);
                    if (datacol != null)
                        employees = datacol;
                }
                else
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    throw new Exception("Error occured at API Endpoint, Error info " + result);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error occured at API Endpoint, Error info " + ex.Message);
            }
            finally { }
            return employees;
        }

        public Employee CreateEmployee(Employee employee)
        {
            if (url.Trim().Substring(0, 5).ToLower() == "https")
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            String json = JsonConvert.SerializeObject(employee);

            try
            {
                HttpResponseMessage response = httpClient.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json")).Result;
                if (response.IsSuccessStatusCode)
                {
                    String result = response.Content.ReadAsStringAsync().Result;
                    var data = JsonConvert.DeserializeObject<Employee>(result);
                    if (data != null)
                        employee = data;
                }
                else
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    throw new Exception("Error occured at API Endpoint, Error info " + result);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error occured at API Endpoint, Error info " + ex.Message);
            }
            finally { }
            return employee;
        }

        public Employee GetEmployee(int id)
        {
            Employee employee = new Employee();
            url = url + "/" + id;
            if (url.Trim().Substring(0, 5).ToLower() == "https")
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            try
            {
                HttpResponseMessage response = httpClient.GetAsync(url).Result;
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    var data = JsonConvert.DeserializeObject<Employee>(result);
                    if (data != null)
                        employee = data;
                }
                else
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    throw new Exception("Error occured at API Endpoint, Error info " + result);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error occured at API Endpoint, Error info " + ex.Message);
            }
            finally { }
            return employee;
        }

        public void UpdateEmployee(Employee employee)
        {
            if (url.Trim().Substring(0, 5).ToLower() == "https")
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            int id = employee.id;
            url = url + "/" + id;
            String json = JsonConvert.SerializeObject(employee);

            try
            {
                HttpResponseMessage response = httpClient.PutAsync(url, new StringContent(json, Encoding.UTF8, "application/json")).Result;
                if (!response.IsSuccessStatusCode)
                {
                    String result = response.Content.ReadAsStringAsync().Result;
                    throw new Exception("Error occured at API Endpoint, Error info " + result);

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error occured at API Endpoint, Error info " + ex.Message);
            }
            finally { }
            return;
        }

        public void DeleteEmployee(int id)
        {
            if (url.Trim().Substring(0, 5).ToLower() == "https")
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            url = url + "/" + id;
            try
            {
                HttpResponseMessage response = httpClient.DeleteAsync(url).Result;
                if (!response.IsSuccessStatusCode)
                {
                    String result = response.Content.ReadAsStringAsync().Result;
                    throw new Exception("Error occured at API Endpoint, Error info " + result);

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error occured at API Endpoint, Error info " + ex.Message);
            }
            finally { }
            return;
        }

    }

}
    

