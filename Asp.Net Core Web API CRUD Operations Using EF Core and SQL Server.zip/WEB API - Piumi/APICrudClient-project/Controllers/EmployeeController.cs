﻿using APICrudClient.Models;
using Microsoft.AspNetCore.Mvc;

namespace APICrudClient.Controllers
{
    public class EmployeeController : Controller

    {
        private readonly APIGateway apiGateway;
        public EmployeeController(APIGateway ApiGateway)
        {
            this.apiGateway = ApiGateway;
        }

        public IActionResult Index()
        {
            List<Employee> employees;
            employees = apiGateway.ListEmployees();
            return View(employees);
        }

        [HttpGet]

        public IActionResult Create()
        {
            Employee employee = new Employee();
            return View(employee);
        }

        [HttpPost]
        public IActionResult Create(Employee employee)
        {
            apiGateway.CreateEmployee(employee);

            return RedirectToAction("Index");
        }
        
        public IActionResult Details(int Id)
        {
            Employee employee = new Employee();

            employee = apiGateway.GetEmployee(Id);

            return View(employee);
        }

        [HttpGet]
        public IActionResult Edit(int Id)
        {
            Employee employee = new Employee();
            employee = apiGateway.GetEmployee(Id);
            return View(employee);
        }
        [HttpPost]
        public IActionResult Edit(Employee employee)
        {
            apiGateway.UpdateEmployee(employee);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Delete(int Id)
        {
            Employee employee;
            employee = apiGateway.GetEmployee(Id);

            return View(employee);
        }
        [HttpPost]
        public IActionResult Delete(Employee employee)
        {
            apiGateway.DeleteEmployee(employee.id);
            return RedirectToAction("Index");
        }
    }
}
